function showBanner(){
	console.log("function called");
	alert("mysite.base");
}
showBanner();