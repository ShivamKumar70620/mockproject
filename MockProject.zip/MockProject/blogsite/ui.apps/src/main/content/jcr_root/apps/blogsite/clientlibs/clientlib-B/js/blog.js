function showBanner2(){
	console.log("function called");
	alert("mysite.B");
}
showBanner2();