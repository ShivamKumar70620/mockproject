function showBanner1(){
	console.log("function called");
	alert("mysite.A");
}
showBanner1();