function showBanner3(){
	console.log("function called");
	alert("mysite.C");
}
showBanner3();