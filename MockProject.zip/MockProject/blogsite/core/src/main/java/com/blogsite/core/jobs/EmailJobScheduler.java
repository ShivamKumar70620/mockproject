package com.blogsite.core.jobs;

import org.apache.sling.event.jobs.JobManager;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Component(service = EmailJobScheduler.class, immediate = true)
public class EmailJobScheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailJobScheduler.class);
    @Reference
    private JobManager jobManager;

    public void scheduleEmailJob(String email, String message) {
        jobManager.addJob("com/example/jobs/email", Map.of(
                "email", email,
                "message", message
        ));
        jobManager.addJob("com/example/jobs/publishContent",Map.of());
    }
}
