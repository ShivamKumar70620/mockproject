package com.blogsite.core.services;


public interface PublishedBlogs {
    int noOfPages();
}
