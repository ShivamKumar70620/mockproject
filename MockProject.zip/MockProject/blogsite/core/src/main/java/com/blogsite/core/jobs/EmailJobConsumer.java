package com.blogsite.core.jobs;


import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
        service = JobConsumer.class,
        property = JobConsumer.PROPERTY_TOPICS + "=com/example/jobs/email",
        immediate = true
)
public class EmailJobConsumer implements JobConsumer{

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailJobConsumer.class);

    @Override
    public JobResult process(Job job) {
        String message = job.getProperty("message", String.class);
        String email = job.getProperty("email", String.class);
        LOGGER.info("This job is triggered.");
        if(sendEmail(email,message)){
            return JobResult.OK;
        }
        else{
            return JobResult.FAILED;
        }
    }
    private boolean sendEmail(String email, String message) {
        LOGGER.info("Email sent to : {} with msg : {}",email,message);
        return true;
    }
}
