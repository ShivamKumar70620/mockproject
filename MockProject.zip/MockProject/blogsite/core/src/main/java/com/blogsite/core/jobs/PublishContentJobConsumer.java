package com.blogsite.core.jobs;

import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;


@Component(
        service = JobConsumer.class,
        property = JobConsumer.PROPERTY_TOPICS + "=com/example/jobs/publishContent",
        immediate = true
)
public class PublishContentJobConsumer implements JobConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishContentJobConsumer.class);

    private static final AtomicInteger attemptCounter = new AtomicInteger(0);
    @Override
    public JobResult process(Job job) {
//        String contentNode = job.getProperty("node",String.class);
        LOGGER.info("This job is triggered.");
        int attempt = attemptCounter.incrementAndGet();
        if(attempt>3){
            LOGGER.error("Job succeeded on attempt: {}", attempt);
            return JobResult.OK;
        }
        else{
            LOGGER.error("Job failed on attempt: {}", attempt);
            return JobResult.FAILED;
        }
    }

}
